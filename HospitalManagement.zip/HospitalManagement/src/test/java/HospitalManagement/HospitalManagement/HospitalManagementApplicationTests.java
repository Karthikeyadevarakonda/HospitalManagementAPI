package HospitalManagement.HospitalManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
